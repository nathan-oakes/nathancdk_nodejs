#!/usr/bin/env python3
import aws_cdk as cdk
from nathancdk.nathancdk_stack import NathancdkStack

app = cdk.App()
NathancdkStack(app, "NathancdkStack")
app.synth()

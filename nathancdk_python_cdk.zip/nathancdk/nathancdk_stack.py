import aws_cdk as cdk
from aws_cdk import (
    aws_sqs as sqs,
    aws_iam as iam,
    aws_ssm as ssm,
)
from constructs import Construct

class NathancdkStack(cdk.Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # --- Pull bootstrap parameters from SSM ---
        # Permissions boundary ARN (must exist in SSM!)
        permissions_boundary_arn = ssm.StringParameter.value_for_string_parameter(
            self, "/bootstrap/permissions-boundary-arn"
        )

        # Example for more parameters (uncomment & add your keys as needed):
        # file_assets_bucket = ssm.StringParameter.value_for_string_parameter(
        #     self, "/bootstrap/file-assets-bucket-name"
        # )
        # kms_key_arn = ssm.StringParameter.value_for_string_parameter(
        #     self, "/bootstrap/file-assets-kms-key-arn"
        # )

        # --- SQS Queue with 5-minute visibility timeout ---
        queue = sqs.Queue(
            self, "NathanCdkQueue",
            queue_name="nathancdk-queue",
            visibility_timeout=cdk.Duration.seconds(300)  # 5 minutes
        )

        # Example: If you wanted to use the permissions boundary for a role (not needed for just SQS)
        # role = iam.Role(
        #     self, "ExampleRole",
        #     assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
        #     permissions_boundary=iam.ManagedPolicy.from_managed_policy_arn(
        #         self, "BoundaryPolicy", permissions_boundary_arn
        #     ),
        # )

        cdk.CfnOutput(self, "QueueUrl", value=queue.queue_url)
        cdk.CfnOutput(self, "QueueArn", value=queue.queue_arn)


# NathanCDK Python AWS CDK Example

This CDK app creates:
- An SQS queue (`nathancdk-queue`) with a 5-minute (300s) visibility timeout
- Looks up all bootstrap parameters from AWS SSM Parameter Store (most importantly `/bootstrap/permissions-boundary-arn`)

## Setup

1. Create the necessary SSM parameters, for example:
    aws ssm put-parameter --name /bootstrap/permissions-boundary-arn --type String --value arn:aws:iam::123456789012:policy/YourBoundaryPolicy

2. Install dependencies:
    python3 -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt

3. Bootstrap your environment (first time only):
    cdk bootstrap

4. Synthesize & deploy:
    cdk synth
    cdk deploy

## Edit & Add More Parameters

To add more SSM parameters, just repeat the lookup in `nathancdk_stack.py` as shown.

